 ./DRAMSim -t traces/k6_short.trc -s system.ini -d ini/DDR3_micron_64M_8B_x4_sg15.ini -c 1000 > results_sumitha/test1.op
